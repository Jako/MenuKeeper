# MenuKeeper

Keep the order of the manager menu after installing or updating an extra.

- Author: Thomas Jakobi <office@treehillstudio.com>
- License: GNU GPLv2

## Features

This extra caches the order of the manager menu before installing or updating an
extra and restores it after the installation or update is finished.
