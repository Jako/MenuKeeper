<?php
/**
 * Setting Lexicon Entries for MenuKeeper
 *
 * @package menukeeper
 * @subpackage lexicon
 */
$_lang['setting_menukeeper.debug'] = 'Debug';
$_lang['setting_menukeeper.debug_desc'] = 'Log debug information in the MODX error log.';
