<?php
/**
 * Setting Lexicon Entries for MenuKeeper
 *
 * @package menukeeper
 * @subpackage lexicon
 */
$_lang['setting_menukeeper.debug'] = 'Debug';
$_lang['setting_menukeeper.debug_desc'] = 'Debug-Informationen im MODX Fehlerprotokoll ausgeben.';
