<?php
/**
 * Setting Lexicon Entries for MenuKeeper
 *
 * @package menukeeper
 * @subpackage lexicon
 */
$_lang['setting_menukeeper.cache_permissions'] = 'Berechtigung Cachen';
$_lang['setting_menukeeper.cache_permissions_desc'] = 'Die Berechtigung jedes Menüpunktes cachen.';
$_lang['setting_menukeeper.debug'] = 'Debug';
$_lang['setting_menukeeper.debug_desc'] = 'Debug-Informationen im MODX Fehlerprotokoll ausgeben.';
