# MenuKeeper

Keep the order of the manager menu after installing or updating an extra.

- Author: Thomas Jakobi <office@treehillstudio.com>
- License: GNU GPLv2

## Features

This extra caches the order of the menu and restores it after the installation
or the update of an extra is finished. It also moves new menu entries added
during installing a package to the bottom.
